// Утилиты для синхронизации игры между ведущим и игроками

export interface GameResult {
  playerName: string
  winner: 'мальчик' | 'девочка'
  timestamp: number
  gameId: string
}

export function saveGameResult(result: GameResult) {
  console.log('Saving game result:', result)
  
  // Сохраняем в localStorage для синхронизации
  const allResults = JSON.parse(localStorage.getItem('game_results') || '[]')
  allResults.push(result)
  localStorage.setItem('game_results', JSON.stringify(allResults))
  
  // Также сохраняем для конкретной игры
  const gameResults = JSON.parse(localStorage.getItem(`game_${result.gameId}_results`) || '[]')
  gameResults.push(result)
  localStorage.setItem(`game_${result.gameId}_results`, JSON.stringify(gameResults))
}

export function getGameResults(gameId: string): GameResult[] {
  return JSON.parse(localStorage.getItem(`game_${gameId}_results`) || '[]')
}

export function markPlayerAsPlayed(gameId: string, playerName: string) {
  const playedGames = JSON.parse(localStorage.getItem(`played_${gameId}`) || '[]')
  if (!playedGames.includes(playerName)) {
    playedGames.push(playerName)
    localStorage.setItem(`played_${gameId}`, JSON.stringify(playedGames))
  }
}

export function hasPlayerPlayed(gameId: string, playerName: string): boolean {
  const playedGames = JSON.parse(localStorage.getItem(`played_${gameId}`) || '[]')
  return playedGames.includes(playerName)
}

export function clearGameData(gameId: string) {
  localStorage.removeItem(`game_${gameId}_results`)
  localStorage.removeItem(`processed_${gameId}`)
  localStorage.removeItem(`played_${gameId}`)
}