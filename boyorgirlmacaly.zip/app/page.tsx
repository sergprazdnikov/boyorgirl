"use client"

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Heart, Users, Smartphone, Crown, Baby } from 'lucide-react'

export default function Home() {
  console.log('Home page rendered')

  return (
    <div className="min-h-screen bg-gradient-to-br from-wedding-lavender via-purple-50 to-pink-50">
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <div className="text-center mb-12">
          <div className="flex justify-center items-center gap-3 mb-6">
            <Heart className="h-12 w-12 text-wedding-pink animate-pulse" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-wedding-pink to-purple-600 bg-clip-text text-transparent">
              Свадебное Гадание
            </h1>
            <Heart className="h-12 w-12 text-wedding-pink animate-pulse" />
          </div>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl">
            Интерактивная игра для свадьбы: гости угадывают "Мальчик или Девочка?"
            через QR-код. Никаких установок - просто сканируй и играй!
          </p>
        </div>

        {/* Navigation Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl w-full">
          <Card className="shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                <Users className="h-8 w-8 text-wedding-pink" />
                Для Ведущего
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="space-y-2 mb-6">
                <p className="text-gray-600">✨ Создайте игру одним кликом</p>
                <p className="text-gray-600">📱 Получите QR-код для гостей</p>
                <p className="text-gray-600">📊 Следите за результатами в реальном времени</p>
                <p className="text-gray-600">🏆 Управляйте счетом</p>
              </div>
              <Link href="/host">
                <Button className="w-full bg-gradient-to-r from-wedding-pink to-purple-500 hover:from-purple-500 hover:to-wedding-pink text-white font-semibold py-3 px-6 rounded-lg shadow-lg transform transition hover:scale-105">
                  Запустить Игру
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                <Smartphone className="h-8 w-8 text-purple-500" />
                Для Гостей
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="space-y-2 mb-6">
                <p className="text-gray-600">📷 Просто сканируйте QR-код</p>
                <p className="text-gray-600">🔤 Нажимайте на клеточки</p>
                <p className="text-gray-600">🎯 Собирайте буквы слов</p>
                <p className="text-gray-600">🎉 Узнайте результат гадания!</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-3">
                  Гости попадают сюда автоматически через QR-код
                </p>
                <div className="bg-gray-100 p-3 rounded-lg text-gray-600">
                  Дождитесь QR-код от ведущего
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Rules */}
        <div className="mt-16 max-w-4xl w-full">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Как играть?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Crown className="h-5 w-5 text-girl-color" />
                    Правила игры
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• 14 закрытых клеток с буквами</li>
                    <li>• 7 букв слова "МАЛЬЧИК" и 7 букв "ДЕВОЧКА"</li>
                    <li>• Гости нажимают клетки в любом порядке</li>
                    <li>• Кто первый соберет слово - тот и выиграл</li>
                    <li>• Результат отображается у ведущего</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Baby className="h-5 w-5 text-boy-color" />
                    Особенности
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Никаких установок приложений</li>
                    <li>• Работает на любых устройствах</li>
                    <li>• Мгновенное отображение результатов</li>
                    <li>• Идеально для свадебных торжеств</li>
                    <li>• Простое управление для ведущего</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
