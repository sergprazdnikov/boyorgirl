"use client"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Heart, Users, Trophy } from 'lucide-react'
import QRCodeGenerator from '@/components/qr-code-generator'
import ScoreBoard from '@/components/score-board'
import { getGameResults, clearGameData, type GameResult } from '@/lib/game-sync'

export default function HostPage() {
  const [gameId, setGameId] = useState<string>('')
  const [gameActive, setGameActive] = useState(false)
  const [scores, setScores] = useState({ girls: 0, boys: 0 })
  const [totalGames, setTotalGames] = useState(0)
  const [gameUrl, setGameUrl] = useState('')

  console.log('Host page rendered, gameActive:', gameActive, 'scores:', scores)

  const createGame = () => {
    const newGameId = Math.random().toString(36).substr(2, 9)
    const url = `${window.location.origin}/play/${newGameId}`
    
    console.log('Creating new game with ID:', newGameId)
    console.log('Game URL:', url)
    
    setGameId(newGameId)
    setGameUrl(url)
    setGameActive(true)
    setScores({ girls: 0, boys: 0 })
    setTotalGames(0)

    // Store game state in localStorage for persistence
    localStorage.setItem('currentGame', JSON.stringify({
      gameId: newGameId,
      active: true,
      scores: { girls: 0, boys: 0 },
      totalGames: 0
    }))
  }

  const stopGame = () => {
    console.log('Stopping game:', gameId)
    setGameActive(false)
    
    // Очищаем все данные игры
    localStorage.removeItem('currentGame')
    if (gameId) {
      clearGameData(gameId)
    }
  }

  const resetScores = () => {
    console.log('Resetting scores')
    setScores({ girls: 0, boys: 0 })
    setTotalGames(0)
    
    if (gameId) {
      // Очищаем все результаты игры используя утилиту
      clearGameData(gameId)
      
      localStorage.setItem('currentGame', JSON.stringify({
        gameId,
        active: true,
        scores: { girls: 0, boys: 0 },
        totalGames: 0
      }))
    }
  }

  // Load game state on component mount
  useEffect(() => {
    const savedGame = localStorage.getItem('currentGame')
    if (savedGame) {
      const gameData = JSON.parse(savedGame)
      console.log('Loading saved game:', gameData)
      
      setGameId(gameData.gameId)
      setGameActive(gameData.active)
      setScores(gameData.scores)
      setTotalGames(gameData.totalGames)
      setGameUrl(`${window.location.origin}/play/${gameData.gameId}`)
    }
  }, [])

  // Polling for game results using the sync utility
  useEffect(() => {
    if (!gameId || !gameActive) return

    const pollForResults = () => {
      const gameResults = getGameResults(gameId)
      const processedResults = JSON.parse(localStorage.getItem(`processed_${gameId}`) || '[]')
      
      // Находим новые результаты
      const newResults = gameResults.filter((result: GameResult) => 
        !processedResults.some((processed: any) => 
          processed.playerName === result.playerName && processed.timestamp === result.timestamp
        )
      )

      if (newResults.length > 0) {
        console.log('New game results found:', newResults)
        
        // Обновляем счетчики
        let newGirls = scores.girls
        let newBoys = scores.boys
        
        newResults.forEach((result: GameResult) => {
          if (result.winner === 'девочка') {
            newGirls++
          } else if (result.winner === 'мальчик') {
            newBoys++
          }
        })

        const newTotalGames = totalGames + newResults.length
        
        setScores({ girls: newGirls, boys: newBoys })
        setTotalGames(newTotalGames)
        
        // Сохраняем обработанные результаты
        const updatedProcessed = [...processedResults, ...newResults]
        localStorage.setItem(`processed_${gameId}`, JSON.stringify(updatedProcessed))
        
        // Обновляем состояние игры
        localStorage.setItem('currentGame', JSON.stringify({
          gameId,
          active: true,
          scores: { girls: newGirls, boys: newBoys },
          totalGames: newTotalGames
        }))
      }
    }

    // Запускаем проверку каждую секунду для более быстрой синхронизации
    const interval = setInterval(pollForResults, 1000)
    return () => clearInterval(interval)
  }, [gameId, gameActive, scores, totalGames])

  return (
    <div className="min-h-screen bg-gradient-to-br from-wedding-lavender via-purple-50 to-pink-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center items-center gap-2 mb-4">
            <Heart className="h-8 w-8 text-wedding-pink" />
            <h1 className="text-4xl font-bold text-gray-800">Свадебное Гадание</h1>
            <Heart className="h-8 w-8 text-wedding-pink" />
          </div>
          <p className="text-lg text-gray-600">Мальчик или Девочка? Пусть гости решат!</p>
        </div>

        {!gameActive ? (
          <Card className="max-w-md mx-auto shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Users className="h-6 w-6" />
                Панель Ведущего
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600 mb-6">
                Нажмите кнопку, чтобы создать новую игру и получить QR-код для гостей
              </p>
              <Button 
                onClick={createGame}
                className="w-full bg-gradient-to-r from-wedding-pink to-purple-500 hover:from-purple-500 hover:to-wedding-pink text-white font-semibold py-3 px-6 rounded-lg shadow-lg transform transition hover:scale-105"
              >
                Создать Игру
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <QRCodeGenerator url={gameUrl} gameId={gameId} />
              <ScoreBoard scores={scores} totalGames={totalGames} />
            </div>
            
            <div className="flex justify-center gap-4">
              <Button 
                onClick={resetScores}
                variant="outline"
                className="border-wedding-pink text-wedding-pink hover:bg-wedding-pink hover:text-white"
              >
                Сбросить Счет
              </Button>
              <Button 
                onClick={stopGame}
                variant="destructive"
              >
                Остановить Игру
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}