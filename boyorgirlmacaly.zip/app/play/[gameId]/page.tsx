"use client"

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Heart, Sparkles, Baby, Crown } from 'lucide-react'
import { toast } from 'sonner'
import GameCell from '@/components/game-cell'
import { Toaster } from '@/components/ui/sonner'
import { saveGameResult, markPlayerAsPlayed, hasPlayerPlayed } from '@/lib/game-sync'

interface GameState {
  cells: (string | null)[]
  cellWords: string[]
  revealedCells: boolean[]
  foundLetters: { [key: string]: string[] }
  gameComplete: boolean
  winner: 'мальчик' | 'девочка' | null
  playerName: string
}

export default function PlayPage() {
  const params = useParams()
  const gameId = params.gameId as string
  
  const [gameState, setGameState] = useState<GameState>({
    cells: [],
    cellWords: [],
    revealedCells: Array(14).fill(false),
    foundLetters: { мальчик: [], девочка: [] },
    gameComplete: false,
    winner: null,
    playerName: ''
  })
  
  const [playerName, setPlayerName] = useState('')
  const [nameEntered, setNameEntered] = useState(false)

  console.log('Play page rendered for gameId:', gameId)
  console.log('Current game state:', gameState)

  // Initialize game
  useEffect(() => {
    if (gameId) {
      initializeGame()
    }
  }, [gameId])

  const initializeGame = () => {
    // Создаем 14 уникальных букв: мальчик (7) + девочка (7), но убираем дубликаты
    const boyLetters = ['м', 'а', 'л', 'ь', 'ч', 'и', 'к']
    const girlLetters = ['д', 'е', 'в', 'о', 'ч', 'к', 'а']
    
    // Создаем набор из 14 позиций: 7 для мальчика, 7 для девочки
    const gameLetters = [
      ...boyLetters.map(letter => ({ letter, word: 'мальчик' })),
      ...girlLetters.map(letter => ({ letter, word: 'девочка' }))
    ]
    
    // Перемешиваем позиции
    const shuffledGameLetters = gameLetters.sort(() => Math.random() - 0.5)
    
    console.log('Initializing game with letters:', shuffledGameLetters)
    
    setGameState(prev => ({
      ...prev,
      cells: shuffledGameLetters.map(item => item.letter),
      cellWords: shuffledGameLetters.map(item => item.word),
      revealedCells: Array(14).fill(false),
      foundLetters: { мальчик: [], девочка: [] },
      gameComplete: false,
      winner: null
    }))
  }

  const handleCellClick = (index: number) => {
    if (gameState.revealedCells[index] || gameState.gameComplete || !nameEntered) {
      return
    }

    // Проверим, играл ли уже этот игрок
    if (hasPlayerPlayed(gameId, playerName)) {
      toast.error('Вы уже играли в эту игру!')
      return
    }

    console.log('Cell clicked:', index, 'Letter:', gameState.cells[index])

    const letter = gameState.cells[index]
    const cellWord = gameState.cellWords[index]
    if (!letter || !cellWord) return

    const newRevealedCells = [...gameState.revealedCells]
    newRevealedCells[index] = true

    const newFoundLetters = { ...gameState.foundLetters }
    newFoundLetters[cellWord] = [...newFoundLetters[cellWord], letter]

    // Проверяем, собрано ли слово полностью
    const boyLetters = ['м', 'а', 'л', 'ь', 'ч', 'и', 'к']
    const girlLetters = ['д', 'е', 'в', 'о', 'ч', 'к', 'а']

    const boyComplete = boyLetters.every(letter => 
      newFoundLetters.мальчик.filter(l => l === letter).length >= boyLetters.filter(l => l === letter).length
    )
    const girlComplete = girlLetters.every(letter => 
      newFoundLetters.девочка.filter(l => l === letter).length >= girlLetters.filter(l => l === letter).length
    )

    let winner: 'мальчик' | 'девочка' | null = null
    let gameComplete = false

    if (boyComplete && !girlComplete) {
      winner = 'мальчик'
      gameComplete = true
    } else if (girlComplete && !boyComplete) {
      winner = 'девочка'
      gameComplete = true
    } else if (boyComplete && girlComplete) {
      // Если оба слова собраны одновременно, определяем по текущей клетке
      winner = cellWord === 'мальчик' ? 'мальчик' : 'девочка'
      gameComplete = true
    }

    setGameState(prev => ({
      ...prev,
      revealedCells: newRevealedCells,
      foundLetters: newFoundLetters,
      gameComplete,
      winner
    }))

    if (gameComplete && winner) {
      console.log('Game completed! Winner:', winner)
      
      // Сохраняем результат игры
      saveGameResult({
        playerName,
        winner,
        timestamp: Date.now(),
        gameId
      })
      
      // Отмечаем игрока как уже игравшего
      markPlayerAsPlayed(gameId, playerName)

      // Show celebration toast
      toast.success(`Поздравляем ${playerName}! Выпало: ${winner.toUpperCase()}!`, {
        duration: 5000,
        description: `Гадание завершено! ${winner === 'мальчик' ? '👦' : '👧'}`
      })
    }
  }

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (playerName.trim()) {
      setNameEntered(true)
      setGameState(prev => ({ ...prev, playerName: playerName.trim() }))
      console.log('Player name entered:', playerName.trim())
    }
  }

  const resetGame = () => {
    console.log('Resetting game')
    setNameEntered(false)
    setPlayerName('')
    // Убираем игрока из списка уже игравших
    const playedGames = JSON.parse(localStorage.getItem(`played_${gameId}`) || '[]')
    const filteredGames = playedGames.filter((name: string) => name !== playerName)
    localStorage.setItem(`played_${gameId}`, JSON.stringify(filteredGames))
    initializeGame()
  }

  if (!nameEntered) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-wedding-lavender via-purple-50 to-pink-50 p-4 flex items-center justify-center">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Heart className="h-6 w-6 text-wedding-pink" />
              Добро пожаловать!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleNameSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Как вас зовут?
                </label>
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="Введите ваше имя"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wedding-pink focus:border-transparent"
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-wedding-pink to-purple-500 hover:from-purple-500 hover:to-wedding-pink text-white font-semibold py-2 px-4 rounded-lg"
              >
                Начать Гадание
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-wedding-lavender via-purple-50 to-pink-50 p-4">
      <Toaster />
      
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <div className="flex justify-center items-center gap-2 mb-2">
            <Sparkles className="h-6 w-6 text-wedding-pink" />
            <h1 className="text-2xl font-bold text-gray-800">Гадание: Мальчик или Девочка?</h1>
            <Sparkles className="h-6 w-6 text-wedding-pink" />
          </div>
          <p className="text-gray-600">Привет, {gameState.playerName}! Нажимай на клеточки и узнай результат!</p>
        </div>

        <div className="mb-6">
          <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8 mb-4 px-2">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Baby className="h-4 w-4 sm:h-5 sm:w-5 text-boy-color" />
                <span className="font-semibold text-boy-color text-sm sm:text-base">МАЛЬЧИК</span>
              </div>
              <div className="flex flex-wrap gap-1 justify-center">
                {['м', 'а', 'л', 'ь', 'ч', 'и', 'к'].map((letter, i) => (
                  <Badge
                    key={i}
                    variant={gameState.foundLetters.мальчик.includes(letter) ? "default" : "outline"}
                    className={`text-xs sm:text-sm ${gameState.foundLetters.мальчик.includes(letter) ? "bg-boy-color text-white" : "border-boy-color text-boy-color"}`}
                  >
                    {letter}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Crown className="h-4 w-4 sm:h-5 sm:w-5 text-girl-color" />
                <span className="font-semibold text-girl-color text-sm sm:text-base">ДЕВОЧКА</span>
              </div>
              <div className="flex flex-wrap gap-1 justify-center">
                {['д', 'е', 'в', 'о', 'ч', 'к', 'а'].map((letter, i) => (
                  <Badge
                    key={i}
                    variant={gameState.foundLetters.девочка.includes(letter) ? "default" : "outline"}
                    className={`text-xs sm:text-sm ${gameState.foundLetters.девочка.includes(letter) ? "bg-girl-color text-white" : "border-girl-color text-girl-color"}`}
                  >
                    {letter}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-6 max-w-sm sm:max-w-2xl mx-auto">
          {gameState.cells.map((letter, index) => (
            <GameCell
              key={index}
              letter={letter}
              cellWord={gameState.cellWords[index]}
              isRevealed={gameState.revealedCells[index]}
              onClick={() => handleCellClick(index)}
              isDisabled={gameState.gameComplete}
            />
          ))}
        </div>

        {gameState.gameComplete && (
          <Card className="shadow-lg border-2 border-wedding-pink">
            <CardContent className="text-center p-6">
              <div className="mb-4">
                {gameState.winner === 'мальчик' ? (
                  <Baby className="h-12 w-12 text-boy-color mx-auto mb-2" />
                ) : (
                  <Crown className="h-12 w-12 text-girl-color mx-auto mb-2" />
                )}
                <h2 className="text-2xl font-bold text-gray-800 mb-2">
                  Гадание завершено!
                </h2>
                <p className="text-xl">
                  Результат: <span className={`font-bold ${gameState.winner === 'мальчик' ? 'text-boy-color' : 'text-girl-color'}`}>
                    {gameState.winner ? gameState.winner.toUpperCase() : ''}
                  </span>
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  Спасибо за участие, {gameState.playerName}! 🎉
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}