"use client"

import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'

interface GameCellProps {
  letter: string | null
  cellWord?: string
  isRevealed: boolean
  onClick: () => void
  isDisabled: boolean
}

export default function GameCell({ letter, cellWord, isRevealed, onClick, isDisabled }: GameCellProps) {
  // Определяем цвет по принадлежности к слову, а не по букве
  const isBoyLetter = cellWord === 'мальчик'
  const isGirlLetter = cellWord === 'девочка'

  console.log('GameCell render:', { letter, isRevealed, isDisabled, isBoyLetter, isGirlLetter })

  return (
    <motion.div
      whileHover={{ scale: isRevealed || isDisabled ? 1 : 1.05 }}
      whileTap={{ scale: isRevealed || isDisabled ? 1 : 0.95 }}
      className="aspect-square"
    >
      <Button
        onClick={onClick}
        disabled={isRevealed || isDisabled}
        className={`
          w-full h-full text-sm sm:text-lg font-bold rounded-lg transition-all duration-300 shadow-md min-h-[40px] sm:min-h-[60px]
          ${isRevealed 
            ? isBoyLetter 
              ? 'bg-boy-color hover:bg-boy-color text-white border-2 border-boy-color' 
              : isGirlLetter 
                ? 'bg-girl-color hover:bg-girl-color text-white border-2 border-girl-color'
                : 'bg-gray-200 hover:bg-gray-200 text-gray-600'
            : 'bg-gradient-to-br from-purple-100 to-pink-100 hover:from-purple-200 hover:to-pink-200 text-gray-700 border-2 border-purple-200 hover:border-purple-300'
          }
          ${!isRevealed && !isDisabled ? 'hover:shadow-lg transform hover:-translate-y-0.5' : ''}
        `}
        variant="outline"
      >
        {isRevealed ? (
          <motion.span
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="text-lg sm:text-xl font-bold"
          >
            {letter?.toUpperCase()}
          </motion.span>
        ) : (
          <motion.div
            animate={{ 
              background: ['linear-gradient(45deg, #e879f9, #c084fc)', 'linear-gradient(45deg, #c084fc, #e879f9)']
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity, 
              repeatType: "reverse" 
            }}
            className="w-6 h-6 rounded bg-gradient-to-br from-purple-400 to-pink-400"
          />
        )}
      </Button>
    </motion.div>
  )
}