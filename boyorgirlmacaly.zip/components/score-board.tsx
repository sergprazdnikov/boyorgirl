"use client"

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Trophy, Baby, Crown, BarChart3 } from 'lucide-react'

interface ScoreBoardProps {
  scores: {
    girls: number
    boys: number
  }
  totalGames: number
}

export default function ScoreBoard({ scores, totalGames }: ScoreBoardProps) {
  const girlsPercentage = totalGames > 0 ? Math.round((scores.girls / totalGames) * 100) : 0
  const boysPercentage = totalGames > 0 ? Math.round((scores.boys / totalGames) * 100) : 0

  console.log('ScoreBoard rendered:', { scores, totalGames, girlsPercentage, boysPercentage })

  return (
    <Card className="shadow-xl">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <Trophy className="h-6 w-6 text-yellow-500" />
          Результаты Гадания
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Score Display */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-gradient-to-br from-pink-50 to-pink-100 rounded-lg border-2 border-girl-color">
            <Crown className="h-8 w-8 text-girl-color mx-auto mb-2" />
            <div className="text-3xl font-bold text-girl-color">{scores.girls}</div>
            <div className="text-sm font-semibold text-girl-color">ДЕВОЧКА</div>
            {totalGames > 0 && (
              <Badge variant="secondary" className="mt-1 bg-girl-color text-white">
                {girlsPercentage}%
              </Badge>
            )}
          </div>
          
          <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-cyan-100 rounded-lg border-2 border-boy-color">
            <Baby className="h-8 w-8 text-boy-color mx-auto mb-2" />
            <div className="text-3xl font-bold text-boy-color">{scores.boys}</div>
            <div className="text-sm font-semibold text-boy-color">МАЛЬЧИК</div>
            {totalGames > 0 && (
              <Badge variant="secondary" className="mt-1 bg-boy-color text-white">
                {boysPercentage}%
              </Badge>
            )}
          </div>
        </div>

        {/* Progress Bars */}
        {totalGames > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Crown className="h-4 w-4 text-girl-color" />
              <div className="flex-1 bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-girl-color h-3 rounded-full transition-all duration-500"
                  style={{ width: `${girlsPercentage}%` }}
                />
              </div>
              <span className="text-sm font-medium w-12 text-right">{girlsPercentage}%</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Baby className="h-4 w-4 text-boy-color" />
              <div className="flex-1 bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-boy-color h-3 rounded-full transition-all duration-500"
                  style={{ width: `${boysPercentage}%` }}
                />
              </div>
              <span className="text-sm font-medium w-12 text-right">{boysPercentage}%</span>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <BarChart3 className="h-5 w-5 text-gray-500" />
            <span className="text-lg font-semibold">Всего игр: {totalGames}</span>
          </div>
          
          {totalGames === 0 ? (
            <p className="text-gray-500 text-sm">Ожидаем первых игроков...</p>
          ) : (
            <div className="space-y-1">
              {scores.girls > scores.boys ? (
                <p className="text-girl-color font-semibold">👑 Лидирует ДЕВОЧКА!</p>
              ) : scores.boys > scores.girls ? (
                <p className="text-boy-color font-semibold">👑 Лидирует МАЛЬЧИК!</p>
              ) : (
                <p className="text-gray-600 font-semibold">🤝 Ничья!</p>
              )}
            </div>
          )}
        </div>

        {/* Winner Badge */}
        {totalGames >= 10 && (
          <div className="text-center p-3 bg-gradient-to-r from-yellow-100 to-yellow-200 rounded-lg border border-yellow-300">
            <Trophy className="h-6 w-6 text-yellow-600 mx-auto mb-1" />
            <p className="text-sm font-semibold text-yellow-800">
              Финальный результат гадания!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}