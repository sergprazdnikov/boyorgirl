"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { QrCode, Copy, CheckCircle } from 'lucide-react'
import QRCode from 'qrcode'

interface QRCodeGeneratorProps {
  url: string
  gameId: string
}

export default function QRCodeGenerator({ url, gameId }: QRCodeGeneratorProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('')
  const [copied, setCopied] = useState(false)

  console.log('QR Code generator props:', { url, gameId })

  useEffect(() => {
    generateQRCode()
  }, [url])

  const generateQRCode = async () => {
    try {
      console.log('Generating QR code for URL:', url)
      const qrUrl = await QRCode.toDataURL(url, {
        width: 256,
        margin: 2,
        color: {
          dark: '#1f2937',
          light: '#ffffff',
        },
      })
      setQrCodeUrl(qrUrl)
      console.log('QR code generated successfully')
    } catch (error) {
      console.error('Error generating QR code:', error)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      console.log('URL copied to clipboard:', url)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Error copying to clipboard:', error)
    }
  }

  return (
    <Card className="shadow-xl">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <QrCode className="h-6 w-6" />
          QR-код для гостей
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        {qrCodeUrl && (
          <div className="bg-white p-4 rounded-lg shadow-inner mx-auto w-fit">
            <img 
              src={qrCodeUrl} 
              alt="QR Code" 
              className="w-48 h-48 mx-auto"
            />
          </div>
        )}
        
        <div className="space-y-2">
          <p className="text-sm text-gray-600">ID игры:</p>
          <p className="font-mono text-lg font-semibold bg-gray-100 px-3 py-2 rounded-lg">
            {gameId}
          </p>
        </div>

        <div className="space-y-2">
          <p className="text-sm text-gray-600">Ссылка на игру:</p>
          <div className="flex items-center gap-2">
            <input
              readOnly
              value={url}
              className="flex-1 px-3 py-2 text-sm bg-gray-100 border rounded-lg text-gray-700"
            />
            <Button
              onClick={copyToClipboard}
              size="sm"
              variant="outline"
              className="flex items-center gap-1"
            >
              {copied ? (
                <>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Скопировано
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  Копировать
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="text-sm text-gray-500 space-y-1">
          <p>📱 Гости сканируют QR-код</p>
          <p>🎮 Играют в гадание</p>
          <p>📊 Результаты отображаются здесь</p>
        </div>
      </CardContent>
    </Card>
  )
}